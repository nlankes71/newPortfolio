﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlackJackLib
{
    public class Hand
    {
        public List<Card> cards = new List<Card>();
        private int _score = 0;

        public int Score
        {
            get { return _score; }
            set { _score = value; }
        }

        public void AddCard(Card card)
        {
            cards.Add(card);
            if (card._face == "A")
            {
                if ((Score + 11) > 21)
                {
                    Score += 1;
                }
                else
                    Score += 11;
            }
            else if(card._face == "10")
                Score += card._value;
            else
                Score += card._value - 1;
        }
    }
}
