﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlackJackLib
{
    public class Deck
    {
        static List<Card> list = new List<Card>();
        static string[] face = new string[] { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
        static string[] suit = new string[] { "\u2666", "\u2665", "\u2663", "\u2660" };
        public Deck()
        {
            for (int i = 0; i < 13; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    Card card = new Card(face[i], suit[x]);
                    list.Add(card);
                }
            }
        }
        public void ShuffleDeck()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            for (int i = 0; i < list.Count; i++)
            {
                int reg = rand.Next(0, list.Count);
                Card card = list[i];
                list.Remove(list[i]);
                list.Insert(reg, card);
            }
        }
        public Card DrawCard()
        {
            Card card = null;
            if (list.Count > 0)
            {
                card = list[0];
                list.Remove(list[0]);
            }
            return card;
        }
    }
}