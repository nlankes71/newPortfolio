﻿using System;

namespace BlackJackLib
{
    public enum Face
    {
        Ace,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King
    }
    public enum Suit
    {
        Diamond,
        Heart,
        Club,
        Spade
    }
    public class Card
    {
        public int _value = 0;
        public string[] _hand = null;
        public string _suit;
        public string _face;

        public string Face(int total)
        {
            string[] face = new string[] { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
            return face[total];
        }
        public Card(string face, string suit)
        {
            _suit = suit;
            _face = face;
            Face name;
            Enum.TryParse(face, out name);
            switch (name)
            {
                case BlackJackLib.Face.Ace:
                    if ((_value + 11) > 21)
                    {
                        _value += 1;
                    }
                    else
                        _value += 11;
                    break;
                case BlackJackLib.Face.Two:
                    _value += 2;
                    break;
                case BlackJackLib.Face.Three:
                    _value += 3;
                    break;
                case BlackJackLib.Face.Four:
                    _value += 4;
                    break;
                case BlackJackLib.Face.Five:
                    _value += 5;
                    break;
                case BlackJackLib.Face.Six:
                    _value += 6;
                    break;
                case BlackJackLib.Face.Seven:
                    _value += 7;
                    break;
                case BlackJackLib.Face.Eight:
                    _value += 8;
                    break;
                case BlackJackLib.Face.Nine:
                    _value += 9;
                    break;
                case BlackJackLib.Face.Ten:
                    _value += 10;
                    break;
                case BlackJackLib.Face.Jack:
                    _value += 10;
                    break;
                case BlackJackLib.Face.Queen:
                    _value += 10;
                    break;
                case BlackJackLib.Face.King:
                    _value += 10;
                    break;
                default:
                    break;
            }
        }

    }
}
