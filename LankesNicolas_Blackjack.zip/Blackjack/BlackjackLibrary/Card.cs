﻿using System;

namespace BlackjackLibrary
{
    public enum Face
    {
        Ace,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King
    }
    public enum Suit
    {
        Diamond,
        Heart,
        Club,
        Spade
    }
    public class Card
    {
        private int _value;
        public string[] _hand = null;
        private string _suit;

        public string Face(int total)
        {
            string[] face = new string[] { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
            return face[total];
        }
        public Card(string face, string suit)
        {
            _suit = suit;
            Face name;
            Enum.TryParse(face, out name);
            switch (name)
            {
                case BlackjackLibrary.Face.Ace:
                    if ((_value + 11) > 21)
                    {
                        _value += 1;
                    }
                    else
                        _value += 11;
                    break;
                case BlackjackLibrary.Face.Two:
                    _value += 2;
                    break;
                case BlackjackLibrary.Face.Three:
                    _value += 3;
                    break;
                case BlackjackLibrary.Face.Four:
                    _value += 4;
                    break;
                case BlackjackLibrary.Face.Five:
                    _value += 5;
                    break;
                case BlackjackLibrary.Face.Six:
                    _value += 6;
                    break;
                case BlackjackLibrary.Face.Seven:
                    _value += 7;
                    break;
                case BlackjackLibrary.Face.Eight:
                    _value += 8;
                    break;
                case BlackjackLibrary.Face.Nine:
                    _value += 9;
                    break;
                case BlackjackLibrary.Face.Ten:
                    _value += 10;
                    break;
                case BlackjackLibrary.Face.Jack:
                    _value += 10;
                    break;
                case BlackjackLibrary.Face.Queen:
                    _value += 10;
                    break;
                case BlackjackLibrary.Face.King:
                    _value += 10;
                    break;
                default:
                    break;
            }
        }

    }
}
