﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlackJackLib;

namespace Blackjack
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Deck deck = new Deck();
            int menuChoice = 0;
            while (true)
            {
            string[] menu = new string[] { "1. Play Blackjack", "2. Shuffle and Show Deck", "3. Exit" };
            ReadChoice("Choice? ", menu, out menuChoice);
                switch (menuChoice)
                {
                    case 1:
                        Console.Clear();
                        deck.ShuffleDeck();
                        Hand player = new Hand();
                        Hand dealer = new Hand();
                        for (int i = 0; i < 2; i++)
                        {
                            player.AddCard(deck.DrawCard());
                            Console.WriteLine("Player drew a " + player.cards[i]._face + player.cards[i]._suit + "\n");
                            dealer.AddCard(deck.DrawCard());
                        }
                        Console.WriteLine("Dealer drew a " + dealer.cards[1]._face + dealer.cards[1]._suit + "\n");
                        bool choice = true;
                        while (player.Score < 21 && choice)
                        {
                            int hitChoice = 0;
                            string[] hitMenu = new string[] { "1. Hit", "2. Hold" };
                            ReadChoice("Choice? ", hitMenu, out hitChoice);
                            switch (hitChoice)
                            {
                                case 1:
                                    player.AddCard(deck.DrawCard());
                                    Console.WriteLine(player.cards[player.cards.Count - 1]._face + player.cards[player.cards.Count - 1]._suit + "\n");
                                    if (player.Score > 21)
                                    {
                                        Console.WriteLine("You bust!");
                                        choice = false;
                                    }
                                    else if (player.Score == 21)
                                    {
                                        Console.WriteLine("Congrats, you hit 21!");
                                        choice = false;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Your total is now " + player.Score);
                                    }
                                    break;
                                case 2:
                                    choice = false;
                                    break;
                                default:
                                    break;
                            }
                        }
                        while (dealer.Score < 17 && player.Score < 21)
                        {
                            dealer.AddCard(deck.DrawCard());
                            Console.WriteLine("\nDealer drew a " + dealer.cards[dealer.cards.Count - 1]._face +dealer.cards[dealer.cards.Count - 1]._suit + "\n");
                            if (dealer.Score > 21)
                            {
                                Console.WriteLine("Dealer busts!");
                            }
                            else if (dealer.Score == 21)
                            {
                                Console.WriteLine("Sorry, the dealer hit 21!");
                            }
                        }
                        Console.WriteLine("Dealer's first card was a  " + dealer.cards[0]._face + dealer.cards[1]._suit + "\n");
                        if ((player.Score > dealer.Score && player.Score <= 21) || (player.Score <= 21 && dealer.Score > 21))
                        {
                            Console.WriteLine("Player had " + player.Score + " and the dealer had " + dealer.Score);
                            Console.WriteLine("You beat the dealer! You win!");
                        }
                        else
                        {
                            Console.WriteLine("Player had " + player.Score + " and the dealer had " + dealer.Score);
                            Console.WriteLine("Sorry, the dealer wins this time!");
                        }
                        break;
                    case 2:
                        Console.Clear();
                        Deck shuffle = new Deck();
                        shuffle.ShuffleDeck();
                        for (int i = 0; i < 52; i++)
                        {
                            Card card = shuffle.DrawCard();
                            Console.WriteLine(card._face + card._suit);
                        }
                        Console.WriteLine("Press any key to continue...");
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("Goodbye.");
                        Console.ReadKey();
                        return;
                    default:
                        break;
                }
                Console.ReadKey();
                Console.Clear();
            }
        }
        public static void ReadString(string ques, ref string value)
        {
            while (true)
            {
                Console.WriteLine($"{ques}");
                value = Console.ReadLine();
                if (!Int32.TryParse(value, out int resp) && value != "")
                {
                    break;
                }
                Console.WriteLine("Please use your words!");
            }
        }
        public static int ReadInteger(string ques)
        {
            string ans;
            int result;
            Console.WriteLine($"{ques}");
            ans = Console.ReadLine();
            while (!Int32.TryParse(ans, out result))
            {
                Console.WriteLine("Thats not a valid number!");
                Console.Write(ques);
                ans = Console.ReadLine();
            }
            return result;
        }
        public static void ReadChoice(string prompt, string[] options, out int selection)
        {
            for (int x = 0; x < options.Length; x++)
            {
                Console.WriteLine($"{options[x]}");
            }
            selection = ReadInteger(prompt);
        }
    }
}
